// load sprite
let trash = App.loadSpritesheet('trash.png', 48, 43, 0, 1);
let tr = 0;
let _stateTimer = 0;

const STATE_INIT = 3000;
const STATE_READY = 3001;
const STATE_PLAYING = 3002;
const STATE_JUDGE = 3004;
const STATE_END = 3005;

let _state = STATE_INIT;

// let _trashCounts = [];
// //let _players = App.players; 

//app 실행 시 최초로 호출되는 이벤트
// App.onInit.Add(function() {
//     //쓰레기 생성
//     //tr = Math.floor(player.length * 5);
//     increase();
// });

function increase() {
    let x = Math.random() * 80; 
    let y = Math.random() * 40;

    Map.putObject(x, y, trash);
}

App.onUpdate.Add(function(dt) {
    // increase();

    _stateTimer += dt;

    switch(_state) {
        case STATE_INIT:
            if(_stateTimer >= 2) {
                App.showCenterLabel("The game will start soon.");
                //increase();
            }
            if(_stateTimer >= 4)
                App.showCenterLabel("Pick Up the Trash");
             if(_stateTimer >= 6)
                 increase();
            break;
        case STATE_PLAYING: 
            break;
        case STATE_JUDGE:
            if(trash == null) {
                App.showCenterLabel("Success");
            }
            else {
                App.showCenterLabel("You Fail");
            }
            break;
            // if(_stateTimer >= 10)
            //     startState(STATE_END);
            // break;

        case STATE_END:
    };
});

// // 플레이어가 오브젝트와 부딪혔을 때 호출 되는 이벤트
// App.onObjectTouched.Add(function(sender, x, y, tileID) {  
//     // 플레이어가 지정된 키를 눌렀을 때 실행(숫자가 같으면 삭제:j)
//     //if(App.addOnKeyDown == 'j'){
//     // 플레이어에게 지정된 위치에 해당 text를 1초간 표시
//     player.showCenterLabel("쓰레기 삭제됨");
//     }
//   //}
// );

// // 게임 블록을 밟았을 때 호출되는 이벤트
// App.onDestroy.Add(function() {
//     for(let i in _trashCounts) {
//         let b = _trashCounts[i];
//         Map.putObject(b[0], b[1], null);
//     }
// });
// 플레이어가 오브젝트를 공격(Z키)했을 때 호출 되는 이벤트
App.onObjectAttacked.Add(function(sender, x, y) {
    Map.clearAllObjects();
});
